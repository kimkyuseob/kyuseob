package com.human.ex2;

public class JavaClass8 {

	public static void main(String[] args) {
		

	}

}
