package com.human.shape;

public class Shape3 {

	public static void main(String[] args) {
		

	}

}
