package com.human.shape;

public class Shape2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("���� 3");//ȭ�鿡 ���
		System.out.println("    *\n   **\n  ***\n ****\n*****");
	}

}
