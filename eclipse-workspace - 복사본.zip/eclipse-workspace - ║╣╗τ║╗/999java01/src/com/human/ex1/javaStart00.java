package com.human.ex1;
public class javaStart00 {
	public static void main(String[] args) {
		 // TODO Auto-generated method stub
	}
}
