package com.human.ex1;

public class JavaStart01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Believer");
System.out.println("Imagine dragons");


	}

}
