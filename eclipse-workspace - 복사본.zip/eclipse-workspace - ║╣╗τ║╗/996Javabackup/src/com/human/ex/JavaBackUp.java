package com.human.ex;

public class JavaBackUp {

	public static void main(String[] args) {
		System.out.println("hello");
		
		

	}

}
